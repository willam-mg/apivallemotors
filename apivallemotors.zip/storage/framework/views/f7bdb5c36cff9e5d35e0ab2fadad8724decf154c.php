<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\pacientemedico\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>