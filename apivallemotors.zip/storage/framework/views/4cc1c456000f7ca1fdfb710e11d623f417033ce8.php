

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Perfil</div>

                <div class="card-body">
                    
                    <div class="row">
                        <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                            <?php if($user->admin): ?>
                                <?php if($user->admin->foto): ?>
                                    <img src="/uploads/<?php echo e($user->admin->foto); ?>" alt="foto" width="100%">
                                <?php else: ?>
                                    <img src="/img/no-image-user.png" alt="foto" width="100%">
                                <?php endif; ?>
                            <?php else: ?>
                                <img src="/img/no-image-user.png" alt="foto" width="100%">
                            <?php endif; ?>
                        </div>
                        <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                            
                            <div class="row">
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 text-right">
                                    <b>Nombre completo:</b>
                                </div>
                                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                                    <?php echo e($user->admin->nombre_completo); ?>

                                </div>
                            </div>
                            <div class="row mt-3">
                                <div class="col-xs-3 col-sm-3 col-md-3 col-lg-3 text-right">
                                    <b>Email:</b>
                                </div>
                                <div class="col-xs-8 col-sm-8 col-md-8 col-lg-8">
                                    <?php echo e($user->email); ?>

                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="row">
                        <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-right">
                            <a href="<?php echo e(route('modificar', $id)); ?>" class="btn btn-warning">
                                Modificar
                            </a>
                        </div>
                    </div>
                    
                    
                        
                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pacientemedico\resources\views/user/profile.blade.php ENDPATH**/ ?>