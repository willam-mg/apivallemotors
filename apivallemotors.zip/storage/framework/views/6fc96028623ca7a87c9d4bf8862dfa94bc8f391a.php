# Info

Welcome to the generated API reference.
<?php if($showPostmanCollectionButton): ?>
[Get Postman Collection](<?php echo e(url($outputPath.'/collection.json')); ?>)
<?php endif; ?><?php /**PATH C:\laragon\www\pacientemedico\vendor\mpociot\laravel-apidoc-generator\src/../resources/views//partials/info.blade.php ENDPATH**/ ?>