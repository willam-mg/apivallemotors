

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Perfil</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('update', $id)); ?>" enctype='multipart/form-data'>
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-xs-12 col-sm-3 col-md-3 col-lg-3">
                                <?php if($user->admin): ?>
                                    <?php if($user->admin->foto): ?>
                                        <img src="/uploads/<?php echo e($user->admin->foto); ?>" alt="foto" width="100%">
                                    <?php else: ?>
                                        <img src="/img/no-image-user.png" alt="foto" width="100%">
                                    <?php endif; ?>
                                <?php else: ?>
                                    <img src="/img/no-image-user.png" alt="foto" width="100%">
                                <?php endif; ?>
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="foto">Foto</label>
                                            <input type="file" accept="image/*" name="foto">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-8 col-md-8 col-lg-8">
                                <div class="row">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="nombre_completo">Nombre completo</label>
                                            <input type="text" class="form-control" value="<?php echo e($user->admin->nombre_completo); ?>" name="nombre_completo">
                                        </div>
                                    </div>
                                </div>
                                <div class="row mt-3">
                                    <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12">
                                        <div class="form-group">
                                            <label for="email">Email</label>
                                            <input type="email" class="form-control" value="<?php echo e($user->email); ?>" name="email">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-xs-12 col-sm-12 col-md-12 col-lg-12 text-right">
                                <a href="<?php echo e(route('profile')); ?>" class="btn btn-default">
                                    Cerrar
                                </a>
                                <button type="submit" class="btn btn-warning">
                                    Modificar
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pacientemedico\resources\views/user/update-profile.blade.php ENDPATH**/ ?>