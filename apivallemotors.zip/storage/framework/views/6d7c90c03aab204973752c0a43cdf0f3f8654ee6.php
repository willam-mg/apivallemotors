<?php $__env->startComponent('mail::message'); ?>
# Codigo de confirmacion

Use este codigo para la aplicacion.
<h1><?php echo e($codigo); ?></h1>

Gracias,<br>
<?php echo e(config('app.name')); ?>

<?php if (isset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d)): ?>
<?php $component = $__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d; ?>
<?php unset($__componentOriginal2dab26517731ed1416679a121374450d5cff5e0d); ?>
<?php endif; ?>
<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\laragon\www\pacientemedico\resources\views/emails/codigo.blade.php ENDPATH**/ ?>