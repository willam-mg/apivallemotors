

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Usuarios</div>

                <div class="card-body">
                    
                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Foto</th>
                                    <th>Nombre completo</th>
                                    <th>Email</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td>
                                            <?php if($user->admin->foto): ?>
                                                <img src="<?php echo e('uploads/'.$user->admin->foto); ?>" alt="foto" width="40px" style="border-radius:50%" height="40px">
                                            <?php else: ?>
                                                <img src="img/no-image-user.png" alt="foto" width="40px" style="border-radius:50%" height="40px">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($user->admin->nombre_completo); ?></td>
                                        <td><?php echo e($user->email); ?></td>
                                        <td>
                                            <a href="<?php echo e(route('profile', ['id' => $user->id])); ?>" class="btn btn-info" title="Ver usuario">
                                                <span class="fa fa-search"></span>
                                                Ver
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>

                    <?php echo e($usuarios->links()); ?>


                    
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\pacientemedico\resources\views/user/index.blade.php ENDPATH**/ ?>